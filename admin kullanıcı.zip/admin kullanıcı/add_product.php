<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
 
    $conn = new mysqli('localhost', 'root', '', 'natural_stones');
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_stock = $_POST['product_stock'];
    $product_category = $_POST['product_category'];
    $product_description = $_POST['product_description'];

    $product_image = $_FILES['product_image']['name'];
    $target_dir = "uploads/";  
    $target_file = $target_dir . basename($product_image);
    
    if (move_uploaded_file($_FILES['product_image']['tmp_name'], $target_file)) {
        echo "Fotoğraf başarılı bir şekilde yüklendi.";
    } else {
        echo "Fotoğraf yüklenemedi.";
        $product_image = null;
    }

  
    $stmt = $conn->prepare("INSERT INTO products (name, price, stock, category, description, image) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sdssss", $product_name, $product_price, $product_stock, $product_category, $product_description, $product_image);

    if ($stmt->execute()) {
        echo "Ürün başarıyla eklendi!";
    } else {
        echo "Ürün eklenirken hata oluştu: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
