<?php
session_start();
$message = "";
include('db_connection.php');


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];


    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
    
        if (password_verify($password, $user['password'])) {
            $_SESSION['user'] = $username;
            header("Location: anasayfa.php");  
            exit();
        } else {
            $message = "Kullanıcı adı veya şifre yanlış!";
        }
    } else {
        $message = "Kullanıcı adı bulunamadı!";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giriş Yap</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #d8bfd8 ;
    }

    .login-container {
        width: 100%;
        max-width: 400px;
        margin: 100px auto;
        padding: 30px;
        background-color: white;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        text-align: center;
    }

    h1 {
        margin-bottom: 20px;
        color: #333;
    }

    form {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    label {
        text-align: left;
        font-weight: bold;
    }

    input {
        padding: 10px;
        font-size: 16px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    button {
        background-color:#7a4fba ;
        color: white;
        padding: 15px;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
    }

    button:hover {
        background-color: #7a4fba ;
    }

    p {
        margin-top: 20px;
    }

    .message {
        color: green;
        margin-bottom: 20px;
    }
    </style>
</head>
<body>

<div class="login-container">
    <h1>Giriş Yap</h1>

    <?php if ($message): ?>
        <p class="error"><?php echo $message; ?></p>
    <?php endif; ?>

    <form method="POST" action="">
        <label for="username">Kullanıcı Adı:</label>
        <input type="text" id="username" name="username" required>

        <label for="password">Şifre:</label>
        <input type="password" id="password" name="password" required>

        <button type="submit">Giriş Yap</button>
    </form>

    <p>Henüz hesabınız yok mu? <a href="register.php">Kayıt Ol</a></p>
</div>

</body>
</html>
