<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "natural_stones";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

$sql = "SELECT * FROM products";
$result = $conn->query($sql);

session_start();


if (isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'];
    $quantity = 1;
    $_SESSION['cart'][] = ['product_id' => $product_id, 'quantity' => $quantity];
}
?>


<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doğal Taşlar</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
     
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #3d3d3d;
        }
       


     
        nav {
            background-color: #B39DDB;
            padding: 15px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            margin-left: 20px;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            justify-content: space-around;
            width: 50%;
        }

        nav ul li a {
            text-decoration: none;
            color: white;
            font-size: 18px;
            font-weight: bold;
            padding: 10px 15px;
            transition: 0.3s;
        }

        nav ul li a:hover {
            color: #8A2BE2;
        }

        .navbar {
    font-size: 18px;
    color: white;
    margin-right: 20px;
    cursor: pointer;
    display: flex;
    align-items: center;
    text-decoration: none; 
}

.navbar a {
    display: flex;
    align-items: center;
    color: white; 
    text-decoration: none;
}

.navbar:hover a {
    color: #8A2BE2; 
}

.navbar i {
    margin-right: 8px;
    font-size: 22px;
}

        .cart {
    font-size: 18px;
    color: white;
    margin-right: 20px;
    cursor: pointer;
    display: flex;
    align-items: center;
    text-decoration: none; 
}

.cart a {
    display: flex;
    align-items: center;
    color: white; 
    text-decoration: none; 
}

.cart:hover a {
    color: #8A2BE2; 
}

.cart i {
    margin-right: 8px;
    font-size: 22px;
}


.search-container {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 20px;
}


.logo {
    margin-right: 15px;
}

.logo-img {
    width: 60px; 
    height: auto;
}


.search-bar {
    padding: 12px 20px;
    font-size: 18px;
    border: 2px solid #D6A8D6; 
    border-radius: 25px; 
    outline: none;
    transition: border-color 0.3s;
    width: 400px; 
}


.search-bar:focus {
    border-color: #9b7dd3;
}


.search-button {
    background-color: #9b7dd3; 
    color: white;
    border: none;
    padding: 12px 25px;
    border-radius: 25px;
    margin-left: 15px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s;
}

.search-button:hover {
    background-color: #8A2BE2; 
}


      
        .banner-container {
            display: flex;
            justify-content: space-between;
            margin: 50px 0;
            padding: 0 20px;
        }

        .banner-item {
            position: relative;
            width: 30%;
            height: 300px;
            background-size: cover;
            background-position: center;
            transition: opacity 0.3s ease;
            opacity: 0.6;
        }

        .banner-item:hover {
            opacity: 1;
        }
     
           .banner-item-1 {
            background-image: url('banner/dogaltas1.jpg');
        }

      
        .banner-item-2 {
            background-image: url('banner/dogaltas2.jpg');
        }

   
        .banner-item-3 {
            background-image: url('banner/dogaltas3.jpg');
        }


        .banner-item h2 {
            position: absolute;
            bottom: 20px;
            left: 20px;
            font-size: 24px;
            color: white;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
            margin: 0;
        }
        
  
.container {
    width: 80%; 
    margin: 0 auto; 
    padding: 40px;
    text-align: center;
}

h1 {
    color: black;
    font-size: 48px;
    position: relative; 
    display: inline-block;
    padding: 10px 20px;
    transition: text-shadow 0.5s ease; 
}

h1:hover {
    color: black; 
    text-shadow: 
        0 0 5px rgba(138, 43, 226, 0.6),  
        0 0 10px rgba(138, 43, 226, 0.6),
        0 0 15px rgba(138, 43, 226, 0.6); 
}
.products-container {
    display: flex;
    flex-wrap: wrap; 
    justify-content: space-between;
    margin-top: 30px;
    padding: 0 50px;
}

.product-card {
    width: 18%; 
    margin-bottom: 50px; 
    margin-left: 30px;
    margin-right: 30px;
    background-color: white;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    text-align: center;
    border-radius: 10px;
    overflow: hidden;
    padding: 15px;
    box-sizing: border-box; 
    position: relative;
}


.product-card img {
    width: 100%;
    height: auto;
    border-bottom: 1px solid #ddd;
}

.product-card h3 {
    font-size: 18px;
    margin: 10px 0;
}

.product-card .price {
    font-size: 20px;
    color: #333;
    margin: 10px 0;
}

.product-card button {
    background-color: #8A2BE2;
    color: white;
    border: none;
    padding: 8px 18px;
    font-size: 14px;
    cursor: pointer;
    margin-bottom: 15px;
    border-radius: 5px;
}

.product-card button:hover {
    background-color: #6A1B9A;
}

.product-card::before,
.product-card::after,
.product-card .top-line,
.product-card .bottom-line,
.product-card .left-line,
.product-card .right-line {
    content: '';
    position: absolute;
    background-color: #D8A7D1; 
    transition: all 0.5s ease;
}


.product-card::before {
    top: 0;
    left: 50%;
    width: 0;
    height: 3px;
    transform: translateX(-50%);
}

.product-card::after {
    bottom: 0;
    left: 50%;
    width: 0;
    height: 3px;
    transform: translateX(-50%);
}


.product-card .left-line {
    top: 50%;
    left: 0;
    height: 0;
    width: 3px;
    transform: translateY(-50%);
}


.product-card .right-line {
    top: 50%;
    right: 0;
    height: 0;
    width: 3px;
    transform: translateY(-50%);
}


.product-card:hover::before {
    width: 100%;
}

.product-card:hover::after {
    width: 100%;
}

.product-card:hover .left-line {
    height: 100%;
}

.product-card:hover .right-line {
    height: 100%;
}

footer {
    background-color: #333;
    color: white;
    padding: 20px 0;
    font-family: Arial, sans-serif;
}

.footer-container {
    display: flex;
    justify-content: space-between;
    padding: 0 50px;
}

.footer-section {
    width: 30%;
}

.footer-section h4 {
    font-size: 20px;
    margin-bottom: 10px;
    color: #9b7dd3; 
}

.footer-section p {
    font-size: 14px;
    line-height: 1.6;
    color: #ddd;
}

.social-media-icons {
    margin-top: 10px;
}

.social-icon {
    text-decoration: none;
    font-size: 20px;
    color: white;
    margin-right: 10px;
    transition: color 0.3s;
}

.social-icon:hover {
    color: #8A2BE2;
}

.footer-bottom {
    text-align: center;
    margin-top: 20px;
    font-size: 14px;
    color: #ddd;
}

.footer-bottom p {
    margin: 0;
}



    </style>
</head>
<body>
    

    <nav>
        
   
    <div class="logo">
            Doğal <span>Taşlar</span>
        </div>
        <ul>
            <li><a href="anasayfa.php">Anasayfa</a></li>
            <li><a href="urunler.php">Ürünler</a></li>
            <li><a href="dogal-tas-ozellikleri.php">Doğal Taş Özellikleri</a></li>
            <li><a href="contact.php">İletişim</a></li>
        </ul>
        <div class="navbar">
        <a href="iletisim.php" class="login-btn">
        <i class="fas fa-sign-in-alt"></i> Giriş
    </a>

        </div>
        <div class="cart">
    <a href="cart.php">
        <i class="fas fa-shopping-cart"></i> Sepetim
    </a>
</div>

    </nav>
    <div class="search-container">
    <div class="logo">
        <img src="logo.png" alt="Logo" class="logo-img">
    </div>
    <input type="text" placeholder="Arama yap..." class="search-bar">
    <button class="search-button">Ara</button>
</div>


    <div class="banner-container">
        <div class="banner-item banner-item-1">
            <h2>Şifa Taşları</h2>
        </div>
        <div class="banner-item banner-item-2">
            <h2>Doğanın Enerjisi</h2>
        </div>
        <div class="banner-item banner-item-3">
            <h2>Ruhsal Denge</h2>
        </div>
    </div>
   

    <div class="container">
        <h1>Ürünlerimiz</h1>
        <div class="hearts">
        
            <span class="heart">&#10084;</span>
           
        </div>
        <div class="products-container">
            <?php
        
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo '<div class="product-card">';
                    echo '<img src="uploads/'.$row['image'].'" alt="'.$row['name'].'">';
                    echo '<h3>'.$row['name'].'</h3>';
                    echo '<div class="price">₺'.$row['price'].'</div>';
                    echo '<form method="POST">';
                    echo '<input type="hidden" name="product_id" value="'.$row['id'].'">';
                    echo '<button type="submit" name="add_to_cart"> <i class="fas fa-shopping-cart"></i> Sepete Ekle</button>';
                    echo '</form>';
                    echo '</div>';
                }
            } else {
                echo "<p>Ürün bulunamadı.</p>";
            }
            ?>
        </div>
    </div>
    <footer>
    <div class="footer-container">
        <div class="footer-section">
            <h4>Hakkımızda</h4>
            <p>"Doğanın enerjisini evinize taşıyoruz!" Şifa Taşları olarak, doğal taşların iyileştirici gücüne inanıyor ve bu eşsiz enerjiyi sizlerle buluşturuyoruz. Kaliteli ve özenle seçilmiş taşlarımızla, ruhunuzu ve yaşam alanlarınızı dengelemenize yardımcı oluyoruz.</p>
        </div>
        <div class="footer-section">
            <h4>İletişim</h4>
            <p>Telefon: +90 222 456 789</p>
            <p>Email: tasritmi@gmail.com</p>
            <p>Adres: Mareşal Fevzi Mahallesi 2.Murat Caddesi No:25 Odunpazarı/Eskişehir </p>
        </div>
        <div class="footer-section">
            <h4>Sosyal Medya</h4>
            <div class="social-media-icons">
                <a href="#" target="_blank" class="social-icon"><i class="fab fa-facebook-f"></i></a>
                <a href="#" target="_blank" class="social-icon"><i class="fab fa-twitter"></i></a>
                <a href="#" target="_blank" class="social-icon"><i class="fab fa-instagram"></i></a>
                <a href="#" target="_blank" class="social-icon"><i class="fab fa-linkedin-in"></i></a>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; 2025 Taş Ritmi. Tüm Hakları Saklıdır.</p>
    </div>
</footer>

</body>
</html>  