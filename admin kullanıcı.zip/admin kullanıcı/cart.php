<?php
session_start();
include('db_connection.php');




if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}


if (isset($_POST['update_cart'])) {
    foreach ($_POST['quantity'] as $key => $quantity) {
        $_SESSION['cart'][$key]['quantity'] = $quantity;
    }
}
if (isset($_GET['remove_item'])) {
    $remove_item = intval($_GET['remove_item']); 
    foreach ($_SESSION['cart'] as $key => $item) {
        if ($item['product_id'] == $remove_item) {
            unset($_SESSION['cart'][$key]); 
            break;
        }
    }
   
    $_SESSION['cart'] = array_values($_SESSION['cart']);
    header("Location: cart.php");
    exit();
}
$cart_items = $_SESSION['cart'];


$total_price = 0;
foreach ($cart_items as $item) {
    $product_id = $item['product_id'];
    $quantity = $item['quantity'];

    $sql = "SELECT price FROM products WHERE id = $product_id";
    $result = $conn->query($sql);
    if ($result && $product = $result->fetch_assoc()) {
        $total_price += $product['price'] * $quantity;
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doğal Taşlar</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
       
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #3d3d3d;
        }
       

nav {
            background-color: #B39DDB;
            padding: 15px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            margin-left: 20px;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            justify-content: space-around;
            width: 50%;
        }

        nav ul li a {
            text-decoration: none;
            color: white;
            font-size: 18px;
            font-weight: bold;
            padding: 10px 15px;
            transition: 0.3s;
        }

        nav ul li a:hover {
            color: #8A2BE2;
        }

        .navbar {
    font-size: 18px;
    color: white;
    margin-right: 20px;
    cursor: pointer;
    display: flex;
    align-items: center;
    text-decoration: none; 
}

.navbar a {
    display: flex;
    align-items: center;
    color: white; 
    text-decoration: none;
}

.navbar:hover a {
    color: #8A2BE2; 
}

.navbar i {
    margin-right: 8px;
    font-size: 22px;
}

        .cart {
    font-size: 18px;
    color: white;
    margin-right: 20px;
    cursor: pointer;
    display: flex;
    align-items: center;
    text-decoration: none; 
}

.cart a {
    display: flex;
    align-items: center;
    color: white; 
    text-decoration: none; 
}

.cart:hover a {
    color: #8A2BE2; 
}

.cart i {
    margin-right: 8px;
    font-size: 22px;
}


.container {
    width: 80%;
    margin: 0 auto;
    padding: 20px;
}

h1 {
    text-align: center;
    color: #6a4e9f;
    font-size: 32px;
    margin-bottom: 20px;
}


table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

table th, table td {
    padding: 10px;
    text-align: center;
    border: 1px solid #ddd;
}

table th {
    background-color: #6a4e9f;
    color: #fff;
}

table td {
    background-color: #fff;
}

input[type="number"] {
    width: 50px;
    padding: 5px;
    text-align: center;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 14px; 
}


.total {
    margin-top: 20px;
    text-align: right;
}

.total p {
    font-size: 18px;
    font-weight: bold;
    color: #333; 
}


button {
    padding: 10px 20px;
    background-color: #6a4e9f;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

button:hover {
    background-color: #5e46a0;
}


.cart-container p {
    text-align: center;
    font-size: 18px;
    color: #666;
}


.checkout {
    text-align: center;
    margin-top: 20px;
}

.checkout a {
    padding: 10px 20px;
    background-color: #6a4e9f;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
    font-size: 18px;
}

.checkout a:hover {
    background-color: #5e46a0;
}




    </style>
</head>
<body>

<nav>
        
   
    <div class="logo">
            Doğal <span>Taşlar</span>
        </div>
        <ul>
            <li><a href="anasayfa.php">Anasayfa</a></li>
            <li><a href="urunler.php">Ürünler</a></li>
            <li><a href="dogal-tas-ozellikleri.php">Doğal Taş Özellikleri</a></li>
            <li><a href="contact.php">İletişim</a></li>
        </ul>
        <div class="navbar">
        <a href="contact.php" class="login-btn">
        <i class="fas fa-sign-in-alt"></i> Giriş
    </a>

        </div>
        <div class="cart">
    <a href="cart.php">
        <i class="fas fa-shopping-cart"></i> Sepetim
    </a>
</div>

    </nav>

    <div class="container">
        <main>
            <h1>Sepetiniz</h1>

            <div class="cart-container">
                <?php if (empty($cart_items)): ?>
                    <p>Sepetinizde ürün bulunmamaktadır.</p>
                <?php else: ?>
                    <form action="cart.php" method="POST">
                        <table>
                            <thead>
                                <tr>
                                    <th>Fotoğraf</th>
                                    <th>Ürün Adı</th>
                                    <th>Fiyat</th>
                                    <th>Miktar</th>
                                    <th>Toplam</th>
                                    <th>Sil</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($cart_items as $index => $item): ?>
                                    <?php
                                    $product_id = $item['product_id'];
                                    $sql = "SELECT * FROM products WHERE id = $product_id";
                                    $result = $conn->query($sql);
                                    if ($result && $product = $result->fetch_assoc()):
                                    ?>
                                        <tr>
                                            <td><img src="uploads/<?php echo $product['image']; ?>" alt="Ürün Resmi" style="width: 50px; height: auto;"></td>
                                            <td><?php echo $product['name']; ?></td>
                                            <td><?php echo $product['price']; ?>₺</td>
                                            <td>
                                                <input type="number" name="quantity[<?php echo $index; ?>]" value="<?php echo $item['quantity']; ?>" min="1">
                                            </td>
                                            <td><?php echo $product['price'] * $item['quantity']; ?>₺</td>
                                            <td><a href="cart.php?remove_item=<?php echo $item['product_id']; ?>">Sil</a>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </tbody>
                        </table>

                        <div class="total">
                            <p>Toplam Tutar: <?php echo $total_price; ?>₺</p>
                            <button type="submit" name="update_cart">Sepeti Güncelle</button>
                        </div>
                    </form>
                    

                    <div class="checkout">
                        <a href="checkout.php">Ödeme Yap</a>
                    </div>
                    
                <?php endif; ?>
                
            </div>
        </main>
    </div>
   
</body>
</html>
